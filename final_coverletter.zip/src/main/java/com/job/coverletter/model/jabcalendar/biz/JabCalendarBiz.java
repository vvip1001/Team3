package com.job.coverletter.model.jabcalendar.biz;

public interface JabCalendarBiz {

}
