package com.job.coverletter.model.coverletter.biz;

public interface CoverLetterBiz {

}
