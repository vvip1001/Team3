package com.job.coverletter.model.skill.dao;

public interface SkillDao {
	String NAMESPACE = "com.job.coverletter.Skill.";
}
