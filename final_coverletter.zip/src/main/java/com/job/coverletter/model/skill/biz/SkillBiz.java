package com.job.coverletter.model.skill.biz;

public interface SkillBiz {

}
