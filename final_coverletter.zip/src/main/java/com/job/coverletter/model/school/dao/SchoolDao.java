package com.job.coverletter.model.school.dao;

public interface SchoolDao {
	String NAMESPACE = "com.job.coverletter.School.";
}
