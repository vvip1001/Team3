package com.job.coverletter.model.coverletter.dao;

public interface CoverLetterDao {
	String NAMESPACE = "com.job.coverletter.CoverLetter.";
}
