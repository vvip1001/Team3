package com.job.coverletter.model.school.biz;

public interface SchoolBiz {

}
