package com.job.coverletter.model.supportPay.biz;

public interface SupportPayBiz {

}
