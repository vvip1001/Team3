package com.job.coverletter.model.jabcalendar.dao;

public interface JabCalendarDao {
	String NAMESPACE = "com.job.coverletter.JabCalender.";
}
