package com.job.coverletter.model.supportPay.dao;

public interface SupportPayDao {
	String NAMESPACE = "com.job.coverletter.Support.";
}
